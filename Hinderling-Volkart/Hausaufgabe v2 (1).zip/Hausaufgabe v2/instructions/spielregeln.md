Kleine Hausaufgabe
==================

Step Navigation
---------------

Erstelle aufgrund der Designvorlage (`design.png`) in `html/step-navigation.html` und `css/style.css` das benötigte HTML/CSS für ein möglichst universell einsetzbares Modul. Finde ausserdem eine responsive Lösung für Mobile.

- HTML nach `html/step-navigation.html`
- CSS nach `css/style.css`
- Das Modul wird auf einer mehrsprachigen Website gebraucht.
- Browser Support: IE9+. FF, Chrome und Safari: aktuellste Version.

Bitte verwende nicht zu viel Zeit für die eigentliche Lösung, ca. 2h (max 3h). Es ist okay, wenn nicht alles fertig ist. Es sind sämtliche Hilfsmittel erlaubt (z.b. SASS). Erläuterungen / Erklärungen bitte nachträglich schriftlich festhalten.

Wir freuen uns auf deine Kreation!
